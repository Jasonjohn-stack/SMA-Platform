AlphaScaled SMA v7.1 - Documents & Chat Patch
===================================================
This bundle adds:
- Document / DDQ module (KYC/AML/DDQ storage with audit trail)
- Chat module with audit logs (rooms, participants, messages, websocket)
- SQL migration for new tables and enums
- RBAC + Storage + Jobs service stubs

How to apply (high level):
1) Copy the 'app/' subfolders into your repository's 'app/'.
2) Run migration: psql "$DATABASE_URL" -f app/db/migrations/2025_11_01_documents_chat.sql
3) Wire RBAC and Storage clients to your environment (S3 or S3-compatible store).
4) In app/main.py add:
   from app.routers import documents, chat
   from app.services.jobs import scheduler_start
   app.include_router(documents.router, prefix="")
   app.include_router(chat.router, prefix="")
   @app.on_event("startup")
   async def startup(): scheduler_start()
5) Restart the API and smoke-test the endpoints.
