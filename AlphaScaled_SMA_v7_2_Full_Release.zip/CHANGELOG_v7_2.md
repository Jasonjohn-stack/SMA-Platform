# AlphaScaled SMA Platform — v7.2 (2025-11-04 UTC)

**New**
- Branding/Theming: tenant logo upload (top-center); presigned S3 upload + retrieval API.
- Integrations Layer: IP allowlist gate + connector stubs (Rubixio ready when keys available).
- Strategy Source Registry for provenance/audit.

**DB**
- Tables: branding_assets, integration_endpoints, integration_allowed_ips, strategy_sources.

**Config**
- Env vars for branding S3, partner APIs, IP allowlist.

**App**
- Routers: /branding/*, /integrations/*.
- app.state.integration_ips for simple allowlist bootstrapping.

Notes: This build layers on v7.1 (Documents & Chat). Ensure v7.1 schema and modules are present.
