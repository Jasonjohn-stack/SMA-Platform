import hashlib, time
from app.services.storage import presigned_post, presigned_get

def make_brand_key(tenant_id: str, filename: str) -> str:
    slug = hashlib.sha256(f"{tenant_id}:{filename}:{time.time()}".encode()).hexdigest()[:16]
    return f"brand/{tenant_id}/{slug}/{filename}"

def presigned_logo_upload(tenant_id: str, filename: str, mime: str, size: int):
    key = make_brand_key(tenant_id, filename)
    url, fields = presigned_post(key, mime, size)
    return key, url, fields

def presigned_logo_get(storage_key: str, ttl: int = 300):
    return presigned_get(storage_key, ttl)
