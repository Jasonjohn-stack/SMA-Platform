# Stub connector for Rubixio (disabled until keys/contracts are finalized)
async def fetch_strategies():
    return []

async def fetch_nav(strategy_code: str, start: str, end: str):
    return []
