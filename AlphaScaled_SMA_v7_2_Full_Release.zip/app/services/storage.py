import hashlib, time
def make_key(owner_type: str, owner_id: str, title: str, user_id: str) -> str:
    slug = hashlib.sha256(f"{owner_type}:{owner_id}:{title}:{user_id}:{time.time()}".encode()).hexdigest()[:16]
    return f"docs/{owner_type}/{owner_id}/{slug}"

def presigned_post(storage_key: str, mime: str, size: int):
    # TODO: integrate boto3 / S3-compatible SDK and return (url, fields)
    return "https://object-store/presigned-post", {"key": storage_key}

def presigned_get(storage_key: str, expires_seconds: int = 60):
    # TODO: integrate boto3 / S3-compatible SDK and return a signed URL string
    return "https://object-store/presigned-get?key=" + storage_key
