from ipaddress import ip_address, ip_network

def client_ip_allowed(client_ip: str, cidrs: list[str]) -> bool:
    try:
        ip = ip_address(client_ip)
        return any(ip in ip_network(c.strip(), strict=False) for c in cidrs if c.strip())
    except Exception:
        return False
