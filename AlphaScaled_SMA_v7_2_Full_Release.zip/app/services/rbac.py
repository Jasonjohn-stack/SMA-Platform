from sqlalchemy.orm import Query, Session
from app.core.auth import User
from app.models.documents import Document
from app.models.chat import ChatRoom, ChatParticipant

# NOTE: Replace these stubs with your real org/role checks.
def filter_docs_for_user(q: Query, user: User) -> Query:
    return q  # TODO: restrict to docs user can access

def can_view_doc(user: User, doc: Document) -> bool:
    return True  # TODO

def can_update_doc(user: User, doc: Document) -> bool:
    return True  # TODO

def can_share_doc(user: User, doc: Document) -> bool:
    return True  # TODO

def filter_rooms_for_user(q: Query, user: User) -> Query:
    return q  # TODO: restrict to rooms where user is participant

def can_view_room(user: User, room_id, db: Session) -> bool:
    return True  # TODO

def can_post_room(user: User, room_id, db: Session) -> bool:
    return True  # TODO

def user_is_room_admin(user: User, room_id, db: Session) -> bool:
    return True  # TODO
