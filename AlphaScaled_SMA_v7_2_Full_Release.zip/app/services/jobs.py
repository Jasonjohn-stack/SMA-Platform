import threading, time
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.core.db import get_sessionmaker
from app.models.documents import Document, DocStatus

RUN = True

def _expiry_loop():
    SessionLocal = get_sessionmaker()
    while RUN:
        try:
            with SessionLocal() as db:  # type: Session
                now = datetime.now(timezone.utc)
                stale = db.query(Document).filter(
                    Document.expires_at != None,
                    Document.expires_at < now,
                    Document.status != DocStatus.EXPIRED
                ).all()
                for d in stale:
                    d.status = DocStatus.EXPIRED
                if stale:
                    db.commit()
        except Exception:
            pass
        time.sleep(3600)  # hourly

def scheduler_start():
    t = threading.Thread(target=_expiry_loop, daemon=True)
    t.start()
