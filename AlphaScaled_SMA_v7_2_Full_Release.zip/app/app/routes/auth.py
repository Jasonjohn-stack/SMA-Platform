
from fastapi import APIRouter
from pydantic import BaseModel, EmailStr
from app.core.security import create_token

router = APIRouter()

class TokenReq(BaseModel):
    email: EmailStr
    role: str = "Allocator"
    tenant_id: str = "00000000-0000-0000-0000-000000000001"

@router.post("/token")
def token(req: TokenReq):
    return {"access_token": create_token(req.email, req.role, req.tenant_id)}
