
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models import Strategy, DailyReturn, BenchmarkReturn
from app.services.kpi_engine import (
    cumulative_return, annualized_vol, sharpe, sortino, cagr, max_drawdown, calmar,
    value_at_risk, expected_shortfall, omega_ratio, gain_pain_ratio, tail_ratio,
    gini_coefficient, outlier_win_loss_ratios, rolling_sharpe, period_returns,
    regression_alpha_beta, information_ratio, treynor_ratio, TRADING_DAYS
)
router = APIRouter()

def _series(db, strategy_code):
    rows = db.query(DailyReturn).filter(DailyReturn.strategy_code==strategy_code).order_by(DailyReturn.d).all()
    return [r.d for r in rows], [r.r for r in rows]

def _bench(db, bench_code, start_date):
    rows = db.query(BenchmarkReturn).filter(BenchmarkReturn.bench_code==bench_code, BenchmarkReturn.d>=start_date).order_by(BenchmarkReturn.d).all()
    return [r.d for r in rows], [r.r for r in rows]

@router.get("/metrics/strategies/overview")
def overview(
    allocator_id: str,
    weight_mode: str = "equal",
    strategy_type: str | None = Query(None),
    risk_profile: str | None = Query(None),
    benchmark_code: str | None = Query("BTC"),
    db: Session = Depends(get_db)
):
    q = db.query(Strategy).filter(Strategy.allocator_id==allocator_id)
    if strategy_type: q = q.filter(Strategy.strategy_type==strategy_type)
    if risk_profile:  q = q.filter(Strategy.risk_profile==risk_profile)
    strats = q.all()

    out_rows = []
    comp_daily = []

    for s in strats:
        dates, rets = _series(db, s.strategy_code)
        if not rets: 
            continue
        days = len(rets)
        cum = cumulative_return(rets)
        avol= annualized_vol(rets)
        shr = sharpe(rets)
        sor = sortino(rets)
        cg  = cagr(rets, days)
        mdd, mdd_s, mdd_e = max_drawdown(rets)
        cal = calmar(cg, mdd)
        var1d = value_at_risk(rets, 0.99)
        cvar1d= expected_shortfall(rets, 0.99)
        var1m = var1d*(21**0.5); cvar1m = cvar1d*(21**0.5)
        omega = omega_ratio(rets, 0.0)
        gp    = gain_pain_ratio(rets)
        tail  = tail_ratio(rets)
        gini  = gini_coefficient(rets)
        ow, ol= outlier_win_loss_ratios(rets, 2.0)
        roll90= rolling_sharpe(rets, 90)
        roll365= rolling_sharpe(rets, 252)
        per = period_returns(dates, rets)

        bench = {"alpha":0,"beta":0,"info_ratio":0,"treynor":0,"corr":0}
        if benchmark_code and dates:
            bd, br = _bench(db, benchmark_code, dates[0])
            ln = min(len(rets), len(br))
            if ln>10:
                a,b,corr = regression_alpha_beta(rets[-ln:], br[-ln:])
                excess = [x-y for x,y in zip(rets[-ln:], br[-ln:])]
                ir = information_ratio(excess)
                tr = treynor_ratio(rets[-ln:], br[-ln:])
                bench = {"alpha":a,"beta":b,"info_ratio":ir,"treynor":tr,"corr":corr}

        out_rows.append({
            "strategy": s.name,
            "strategy_code": s.strategy_code,
            "strategy_type": s.strategy_type or "Unclassified",
            "risk_profile": s.risk_profile,
            "cumulative_return": cum,
            "cagr": cg,
            "volatility": avol,
            "sharpe": shr,
            "sortino": sor,
            "calmar": cal,
            "max_drawdown": mdd,
            "mdd_start_index": mdd_s,
            "mdd_end_index": mdd_e,
            "var_1d": var1d,
            "var_1m": var1m,
            "cvar_1d": cvar1d,
            "cvar_1m": cvar1m,
            "gini_coefficient": gini,
            "omega_ratio": omega,
            "gain_pain_ratio": gp,
            "tail_ratio": tail,
            "outlier_win_avg": ow,
            "outlier_loss_avg": ol,
            "rolling_sharpe_90d_mean": roll90["mean"],
            "rolling_sharpe_90d_median": roll90["median"],
            "rolling_sharpe_90d_last": roll90["last"],
            "rolling_sharpe_365d_mean": roll365["mean"],
            "rolling_sharpe_365d_median": roll365["median"],
            "rolling_sharpe_365d_last": roll365["last"],
            "periods": per,
            "benchmark": bench
        })

        comp_daily.append(rets)

    composite = {}
    if comp_daily:
        min_len = min(len(x) for x in comp_daily)
        merged = [sum(x[-min_len:][i] for x in comp_daily)/len(comp_daily) for i in range(min_len)]
        cd = len(merged)
        cg = cagr(merged, cd); md = max_drawdown(merged)[0]
        composite = {"cagr": cg, "sharpe": sharpe(merged), "max_drawdown": md, "calmar": calmar(cg, md)}

    return {"allocator_id": allocator_id, "mode": weight_mode, "strategies": out_rows, "composite": composite}
