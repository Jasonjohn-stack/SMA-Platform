
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models import Position
from collections import defaultdict

router = APIRouter()

@router.post("/metrics/exposures/recompute")
def recompute(allocator_id: str, strategy_id: str, db: Session = Depends(get_db)):
    rows = db.query(Position).filter(Position.strategy_code==strategy_id).all()
    gross = sum(abs(r.usd_value) for r in rows)
    net = sum(r.usd_value for r in rows)
    long = sum(max(0,r.usd_value) for r in rows)
    short = sum(-min(0,r.usd_value) for r in rows)
    by_symbol = defaultdict(float); by_venue = defaultdict(float)
    for r in rows:
        by_symbol[r.symbol]+= r.usd_value
        by_venue[r.venue]+= r.usd_value
    return {"gross": gross, "net": net, "long": long, "short": short,
            "by_symbol": by_symbol, "by_venue": by_venue}
