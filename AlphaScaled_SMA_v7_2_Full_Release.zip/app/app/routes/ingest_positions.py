
from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
import csv, io, datetime as dt
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models import Position

router = APIRouter()

@router.post("/ingest/positions")
async def ingest_positions(strategy_code: str, file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.endswith(".csv"):
        raise HTTPException(400, "Upload a CSV with columns: symbol, venue, usd_value, asof")
    content = (await file.read()).decode()
    r = csv.DictReader(io.StringIO(content))
    rows = 0
    for row in r:
        asof = dt.date.fromisoformat(row["asof"])
        db.add(Position(strategy_code=strategy_code, symbol=row["symbol"], venue=row["venue"], usd_value=float(row["usd_value"]), asof=asof))
        rows += 1
    db.commit()
    return {"ingested": rows}
