
from fastapi import APIRouter, Response

router = APIRouter()

@router.get("/templates/returns.csv")
def returns_tpl():
    csv = "date,return\n2025-01-02,0.004\n2025-01-03,-0.006\n"
    return Response(content=csv, media_type="text/csv")

@router.get("/templates/positions.csv")
def positions_tpl():
    csv = "symbol,venue,usd_value,asof\nBTC-USD,Coinbase,150000,2025-01-03\nETH-USD,Binance,-40000,2025-01-03\n"
    return Response(content=csv, media_type="text/csv")
