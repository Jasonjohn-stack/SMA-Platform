
from fastapi import APIRouter, HTTPException, Response
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
import secrets, base64, urllib.parse, os
from app.core.security import create_token
from app.core.emailer import send_magic_link

router = APIRouter()
PENDING = {}

class MagicRequest(BaseModel):
    email: EmailStr
    tenant_id: str | None = None

@router.post("/request")
def request_magic(req: MagicRequest):
    opaque = base64.urlsafe_b64encode(secrets.token_bytes(24)).decode().rstrip("=")
    PENDING[opaque] = {"email": req.email, "tenant_id": req.tenant_id or "00000000-0000-0000-0000-000000000001", "exp": datetime.utcnow() + timedelta(minutes=15)}
    base = os.getenv("PUBLIC_BASE_URL","")
    link = f"/auth/magic/verify?token={urllib.parse.quote(opaque)}"
    abs_link = (base.rstrip('/') + link) if base else link
    res = send_magic_link(req.email, abs_link)
    out = {"status":"ok","emailed":res.get("sent",False),"note":res.get("reason")}
    if not res.get("sent",False):
        out["magic_link"] = link
    return out

@router.get("/verify")
def verify_magic(token: str):
    data = PENDING.get(token)
    if not data: raise HTTPException(400, "Invalid or expired token")
    if data["exp"] < datetime.utcnow():
        del PENDING[token]; raise HTTPException(400, "Token expired")
    jwt_token = create_token(subject=data["email"], role="Allocator", tenant_id=data["tenant_id"], minutes=120)
    del PENDING[token]
    html = f"""<!doctype html><html><head><meta charset='utf-8'><title>Signing in…</title>
<script>localStorage.setItem('token','{jwt_token}');window.location.href='/static/allocator.html';</script>
</head><body>Signing you in…</body></html>"""
    return Response(content=html, media_type="text/html")
