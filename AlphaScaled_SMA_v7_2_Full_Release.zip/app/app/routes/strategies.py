
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models import Strategy

router = APIRouter()

@router.get("/strategies")
def list_strategies(
    db: Session = Depends(get_db),
    allocator_id: str | None = Query(None),
    strategy_type: str | None = Query(None),
    risk_profile: str | None = Query(None),
    q: str | None = Query(None),
    limit: int = 200
):
    qset = db.query(Strategy)
    if allocator_id:   qset = qset.filter(Strategy.allocator_id==allocator_id)
    if strategy_type:  qset = qset.filter(Strategy.strategy_type==strategy_type)
    if risk_profile:   qset = qset.filter(Strategy.risk_profile==risk_profile)
    if q:
        like=f"%{q.lower()}%"
        qset = qset.filter((Strategy.name.ilike(like)) | (Strategy.strategy_code.ilike(like)))
    rows = qset.limit(limit).all()
    return [{
        "id": s.id, "name": s.name, "code": s.strategy_code,
        "strategy_type": s.strategy_type, "style_subtype": s.style_subtype,
        "risk_profile": s.risk_profile, "investment_horizon": s.investment_horizon,
        "style_tags": s.style_tags or []
    } for s in rows]
