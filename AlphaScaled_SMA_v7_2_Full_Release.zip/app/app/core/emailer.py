
import os, smtplib
from email.mime.text import MIMEText
from email.utils import formataddr

def send_magic_link(to_email: str, magic_url: str) -> dict:
    if os.getenv("SEND_EMAIL","0") != "1":
        return {"sent": False, "reason": "SEND_EMAIL not enabled"}
    host = os.getenv("SMTP_HOST"); port = int(os.getenv("SMTP_PORT","587"))
    user = os.getenv("SMTP_USER"); pwd = os.getenv("SMTP_PASS")
    from_email = os.getenv("SMTP_FROM_EMAIL", user or "noreply@example.com")
    from_name  = os.getenv("SMTP_FROM_NAME","AlphaScaled Login")
    if not (host and user and pwd):
        return {"sent": False, "reason": "SMTP not configured"}
    subject = "Your AlphaScaled sign-in link"
    body = f"Click to sign in: {magic_url}\n\nThis link expires soon."
    msg = MIMEText(body); msg["Subject"]=subject; msg["From"]=formataddr((from_name, from_email)); msg["To"]=to_email
    try:
        with smtplib.SMTP(host, port) as s:
            s.starttls(); s.login(user, pwd); s.sendmail(from_email, [to_email], msg.as_string())
        return {"sent": True, "reason": "sent"}
    except Exception as e:
        return {"sent": False, "reason": str(e)}
