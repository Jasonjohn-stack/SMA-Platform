
import os
from datetime import datetime, timedelta, timezone
from jose import jwt

JWT_SECRET = os.getenv("JWT_SECRET","dev-secret")
JWT_ALGO = os.getenv("JWT_ALGO","HS256")

def create_token(subject: str, role: str, tenant_id: str, minutes: int = 120):
    now = datetime.now(timezone.utc)
    payload = {
        "sub": subject,
        "role": role,
        "tenant": tenant_id,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=minutes)).timestamp())
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)
