
from sqlalchemy import Column, Integer, String, Float, Date, JSON
from app.db.session import Base

class Strategy(Base):
    __tablename__ = "strategies"
    id = Column(Integer, primary_key=True)
    strategy_code = Column(String, unique=True, index=True)
    name = Column(String)
    allocator_id = Column(String)
    tenant_id = Column(String)
    strategy_type = Column(String(80))
    style_subtype = Column(String(120))
    risk_profile = Column(String(32))
    investment_horizon = Column(String(32))
    style_tags = Column(JSON, default=list)

class DailyReturn(Base):
    __tablename__ = "daily_returns"
    id = Column(Integer, primary_key=True)
    strategy_code = Column(String, index=True)
    d = Column(Date, index=True)
    r = Column(Float)

class Position(Base):
    __tablename__ = "positions"
    id = Column(Integer, primary_key=True)
    strategy_code = Column(String, index=True)
    symbol = Column(String)
    venue = Column(String)
    usd_value = Column(Float)
    asof = Column(Date)


from sqlalchemy import Column, Integer, String, Float, Date
from app.db.session import Base

class BenchmarkReturn(Base):
    __tablename__ = "benchmark_returns"
    id = Column(Integer, primary_key=True)
    bench_code = Column(String, index=True)
    d = Column(Date, index=True)
    r = Column(Float)
