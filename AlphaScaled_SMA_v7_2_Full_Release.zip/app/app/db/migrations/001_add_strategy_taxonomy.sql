
-- v7.0 Strategy Taxonomy and base tables
CREATE TABLE IF NOT EXISTS strategies(
    id SERIAL PRIMARY KEY,
    strategy_code VARCHAR UNIQUE,
    name VARCHAR,
    allocator_id VARCHAR,
    tenant_id VARCHAR,
    strategy_type VARCHAR(80),
    style_subtype VARCHAR(120),
    risk_profile VARCHAR(32),
    investment_horizon VARCHAR(32),
    style_tags JSONB DEFAULT '[]'::jsonb
);
CREATE TABLE IF NOT EXISTS daily_returns(
    id SERIAL PRIMARY KEY,
    strategy_code VARCHAR,
    d DATE,
    r DOUBLE PRECISION
);
CREATE TABLE IF NOT EXISTS positions(
    id SERIAL PRIMARY KEY,
    strategy_code VARCHAR,
    symbol VARCHAR,
    venue VARCHAR,
    usd_value DOUBLE PRECISION,
    asof DATE
);
CREATE INDEX IF NOT EXISTS ix_returns_sc_d ON daily_returns(strategy_code, d);
CREATE INDEX IF NOT EXISTS ix_positions_sc ON positions(strategy_code);
CREATE INDEX IF NOT EXISTS idx_strategies_type ON strategies(strategy_type);


CREATE TABLE IF NOT EXISTS benchmark_returns(
    id SERIAL PRIMARY KEY,
    bench_code VARCHAR,
    d DATE,
    r DOUBLE PRECISION
);
CREATE INDEX IF NOT EXISTS ix_bench_code_d ON benchmark_returns(bench_code, d);
