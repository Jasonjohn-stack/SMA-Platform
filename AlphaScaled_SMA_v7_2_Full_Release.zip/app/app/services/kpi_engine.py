
from __future__ import annotations
from typing import List, Dict, Tuple
import math, statistics as stats

TRADING_DAYS = 252

def cumulative_return(returns: List[float]) -> float:
    eq=1.0
    for r in returns: eq*=(1+r)
    return eq-1.0

def annualized_vol(returns: List[float]) -> float:
    if len(returns) < 2: return 0.0
    return stats.pstdev(returns) * (TRADING_DAYS ** 0.5)

def sharpe(returns: List[float], rf: float = 0.0) -> float:
    if not returns: return 0.0
    mu = (sum(returns)/len(returns))*TRADING_DAYS - rf
    vol = annualized_vol(returns)
    return (mu/vol) if vol else 0.0

def sortino(returns: List[float], rf: float = 0.0) -> float:
    if not returns: return 0.0
    downside = [min(0.0, r) for r in returns]
    if len(downside) < 2: return 0.0
    dd_vol = stats.pstdev(downside) * (TRADING_DAYS ** 0.5)
    mu = (sum(returns)/len(returns))*TRADING_DAYS - rf
    return (mu/dd_vol) if dd_vol else 0.0

def cagr(returns: List[float], days:int) -> float:
    if not returns: return 0.0
    eq=1.0
    for r in returns: eq*=(1+r)
    years = max(1/TRADING_DAYS, days/float(TRADING_DAYS))
    return (eq**(1/years)-1) if eq>0 else 0.0

def max_drawdown(returns: List[float]) -> Tuple[float,int,int]:
    eq=1.0; peak=1.0; mdd=0.0; s=0; start=0; end=0
    for i,r in enumerate(returns):
        eq*=(1+r)
        if eq>peak: peak=eq; s=i
        dd = eq/peak-1
        if dd<mdd: mdd=dd; start=s; end=i
    return (mdd,start,end)

def calmar(cagr_v: float, mdd: float) -> float:
    return (cagr_v/abs(mdd)) if mdd!=0 else 0.0

def value_at_risk(returns: List[float], p: float=0.99) -> float:
    if not returns: return 0.0
    s=sorted(returns)
    k=max(0,int((1-p)*len(s))-1)
    return -s[k]

def expected_shortfall(returns: List[float], p: float=0.99) -> float:
    if not returns: return 0.0
    s=sorted(returns)
    k=max(1,int((1-p)*len(s)))
    tail=s[:k]
    return - (sum(tail)/len(tail)) if tail else 0.0

def omega_ratio(returns: List[float], threshold: float=0.0) -> float:
    gains=[max(0,r-threshold) for r in returns]
    losses=[max(0,threshold-r) for r in returns]
    den=sum(losses)
    return (sum(gains)/den) if den else float('inf')

def gain_pain_ratio(returns: List[float]) -> float:
    g=sum(x for x in returns if x>0)
    p=-sum(x for x in returns if x<0)
    return g/p if p else float('inf')

def tail_ratio(returns: List[float]) -> float:
    if not returns: return 0.0
    s=sorted(returns)
    q95=s[int(0.95*(len(s)-1))]
    q05=s[int(0.05*(len(s)-1))]
    return (q95/abs(q05)) if q05!=0 else float('inf')

def gini_coefficient(values: List[float]) -> float:
    if not values: return 0.0
    s=sorted([abs(v) for v in values])
    n=len(s)
    cum=0.0
    for i,v in enumerate(s, start=1): cum += i*v
    total=sum(s)
    if total==0: return 0.0
    return (2*cum)/(n*total) - (n+1)/n

def outlier_win_loss_ratios(returns: List[float], z: float=2.0) -> Tuple[float,float]:
    if not returns: return (0.0,0.0)
    mu=sum(returns)/len(returns)
    sd=stats.pstdev(returns) if len(returns)>1 else 0.0
    if sd==0: return (0.0,0.0)
    wins=[r for r in returns if r>mu+z*sd]
    losses=[r for r in returns if r<mu-z*sd]
    avg_pos=sum(wins)/len(wins) if wins else 0.0
    avg_neg=-sum(losses)/len(losses) if losses else 0.0
    return (avg_pos, avg_neg)

def rolling_sharpe(returns: List[float], window:int=90) -> Dict[str,float]:
    if len(returns)<window: return {"mean":0.0,"median":0.0,"last":0.0}
    vals=[]
    for i in range(window, len(returns)+1):
        chunk=returns[i-window:i]
        vals.append(sharpe(chunk))
    import statistics as st
    return {"mean":st.mean(vals), "median":st.median(vals), "last":vals[-1]}

def period_returns(dates, returns):
    if not returns: return {"MTD":0,"3M":0,"6M":0,"YTD":0,"best_day":0,"worst_day":0,"best_month":0,"worst_month":0,"best_year":0,"worst_year":0}
    from collections import defaultdict
    from datetime import timedelta
    today=dates[-1]
    m0=today.replace(day=1)
    y0=today.replace(month=1, day=1)
    def cum_between(start_date):
        v=1.0
        for d,r in zip(dates, returns):
            if d>=start_date: v*=(1+r)
        return v-1.0
    mtd=cum_between(m0)
    ytd=cum_between(y0)
    r3=cum_between(today - timedelta(days=90))
    r6=cum_between(today - timedelta(days=180))
    best_day=max(returns); worst_day=min(returns)
    month_map=defaultdict(list); year_map=defaultdict(list)
    for d,r in zip(dates, returns):
        month_map[(d.year,d.month)].append(r); year_map[d.year].append(r)
    def cum(rr): 
        v=1.0
        for x in rr: v*=(1+x)
        return v-1.0
    best_month=max([cum(v) for v in month_map.values()]) if month_map else 0.0
    worst_month=min([cum(v) for v in month_map.values()]) if month_map else 0.0
    best_year=max([cum(v) for v in year_map.values()]) if year_map else 0.0
    worst_year=min([cum(v) for v in year_map.values()]) if year_map else 0.0
    return {"MTD":mtd,"3M":r3,"6M":r6,"YTD":ytd,"best_day":best_day,"worst_day":worst_day,
            "best_month":best_month,"worst_month":worst_month,"best_year":best_year,"worst_year":worst_year}

def regression_alpha_beta(asset: List[float], bench: List[float]):
    if not asset or not bench or len(asset)!=len(bench): return (0.0,0.0,0.0)
    am=sum(asset)/len(asset); bm=sum(bench)/len(bench)
    cov=sum((a-am)*(b-bm) for a,b in zip(asset,bench))/len(asset)
    varb=sum((b-bm)**2 for b in bench)/len(bench)
    beta=cov/varb if varb else 0.0
    alpha_daily=am - beta*bm
    sd_a=(sum((a-am)**2 for a in asset)/len(asset))**0.5
    sd_b=(sum((b-bm)**2 for b in bench)/len(bench))**0.5
    corr=cov/(sd_a*sd_b) if (sd_a and sd_b) else 0.0
    return (alpha_daily*TRADING_DAYS, beta, corr)

def information_ratio(asset_exc: List[float]) -> float:
    if not asset_exc: return 0.0
    mu=(sum(asset_exc)/len(asset_exc))*TRADING_DAYS
    tr=stats.pstdev(asset_exc)*(TRADING_DAYS**0.5) if len(asset_exc)>1 else 0.0
    return (mu/tr) if tr else 0.0

def treynor_ratio(asset: List[float], bench: List[float], rf_annual: float=0.0) -> float:
    alpha,beta,corr = regression_alpha_beta(asset, bench)
    if beta==0: return 0.0
    mu_a=(sum(asset)/len(asset))*TRADING_DAYS - rf_annual
    return mu_a/beta
