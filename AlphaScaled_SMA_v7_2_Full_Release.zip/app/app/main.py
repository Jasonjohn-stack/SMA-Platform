
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.routes import auth, auth_magic, ingest_nav, ingest_positions, strategy_overview, exposures, strategies, templates

app = FastAPI(title="AlphaScaled SMA API", version="0.7.2")
app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(auth_magic.router, prefix="/auth/magic", tags=["Auth"])
app.include_router(ingest_nav.router, tags=["Ingest"])
app.include_router(ingest_positions.router, tags=["Ingest"])
app.include_router(strategy_overview.router, tags=["Metrics"])
app.include_router(exposures.router, tags=["Metrics"])
app.include_router(strategies.router, tags=["Strategies"])
app.include_router(templates.router, tags=["Templates"])

app.mount("/static", StaticFiles(directory="app/static"), name="static")
