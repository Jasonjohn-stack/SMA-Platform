
# AlphaScaled SMA — v7.0 (All-in-one)
Strategy Taxonomy + Allocator/PM portals + Magic-link auth + KPIs + Exposures (demo)

## Run (demo)
```
cd app
docker-compose up --build -d
docker exec -it sma_api bash -lc "python seed.py"
# API docs: http://localhost:8000/docs
# Login:    http://localhost:8000/static/login.html
# Portal:   http://localhost:8000/static/allocator.html
# PM UI:    http://localhost:8000/static/upload.html
# Grafana:  http://localhost:3000  (admin/admin)
```
