
from app.db.session import engine, Base, SessionLocal
from app.db.models import Strategy, DailyReturn, Position, BenchmarkReturn
import datetime as dt
import random

def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    S = [
        dict(strategy_code="Quant-Arb-001", name="Quant Arb 001", allocator_id="allocator_001", tenant_id="000...001",
             strategy_type="Statistical Arbitrage", risk_profile="Moderate", style_subtype="Market Neutral", investment_horizon="Short-term", style_tags=["stat-arb","market-neutral","btc","eth"]),
        dict(strategy_code="MR-ALTS-001", name="Altcoin Mean Reversion", allocator_id="allocator_001", tenant_id="000...001",
             strategy_type="Mean Reversion", risk_profile="Moderate", style_subtype="Short-Term Reversal", investment_horizon="Short-term", style_tags=["mean-reversion","alts"]),
    ]
    for s in S:
        if not db.query(Strategy).filter_by(strategy_code=s["strategy_code"]).first():
            db.add(Strategy(**s))
    db.commit()
    start = dt.date.today() - dt.timedelta(days=300)
    for s in S:
        code = s["strategy_code"]
        for i in range(280):
            d = start + dt.timedelta(days=i)
            if d.weekday()>=5: 
                continue
            r = random.gauss(0.0006 if "Quant" in code else 0.0004, 0.01)
            db.add(DailyReturn(strategy_code=code, d=d, r=r))
    db.commit()
    pos = [
        dict(strategy_code="Quant-Arb-001", symbol="BTC-USD", venue="Coinbase", usd_value=150000, asof=dt.date.today()),
        dict(strategy_code="Quant-Arb-001", symbol="ETH-USD", venue="Binance", usd_value=-40000, asof=dt.date.today()),
        dict(strategy_code="MR-ALTS-001", symbol="SOL-USD", venue="Binance", usd_value=50000, asof=dt.date.today()),
    ]
    for p in pos: db.add(Position(**p))
    db.commit(); db.close(); print("Seed complete.")

if __name__ == "__main__":
    seed()


    # Benchmark BTC synthetic series
    start_b = dt.date.today() - dt.timedelta(days=300)
    for i in range(280):
        d = start_b + dt.timedelta(days=i)
        if d.weekday()>=5: 
            continue
        r = random.gauss(0.0005, 0.03)
        db.add(BenchmarkReturn(bench_code="BTC", d=d, r=r))
    db.commit()
