from fastapi import APIRouter, Depends, Request, HTTPException, Query
from sqlalchemy.orm import Session
from datetime import date
from app.core.db import get_db
from app.core.security import current_user
from app.core.auth import User
from app.services.ip_whitelist import client_ip_allowed
from app.services.connectors import rubixio

router = APIRouter(prefix='/integrations', tags=['integrations'])

def _allowed(request: Request) -> bool:
    env_ips = (getattr(request.app.state, 'integration_ips', '') or '').split(',')
    client_ip = request.client.host
    return client_ip_allowed(client_ip, env_ips)

@router.get('/seed/rubixio')
async def seed_rubixio(
    request: Request,
    tenant_id: str = Query(...),
    start: date = Query(...),
    end: date = Query(...),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if not _allowed(request):
        raise HTTPException(403, 'IP not allowed for integration endpoint')
    strategies = await rubixio.fetch_strategies()
    return {'imported': len(strategies), 'tenant_id': tenant_id, 'window': [str(start), str(end)]}
