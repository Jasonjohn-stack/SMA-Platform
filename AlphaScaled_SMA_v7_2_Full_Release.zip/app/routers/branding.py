from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.core.security import current_user
from app.core.auth import User
from app.models.branding import BrandingAsset
from app.services.branding_storage import presigned_logo_upload, presigned_logo_get

router = APIRouter(prefix='/branding', tags=['branding'])

class PrepareLogoUpload(BaseModel):
    tenant_id: str
    filename: str
    mime_type: str
    bytes: int

@router.post('/logo/prepare')
def prepare_logo_upload(payload: PrepareLogoUpload, user: User = Depends(current_user), db: Session = Depends(get_db)):
    key, url, fields = presigned_logo_upload(payload.tenant_id, payload.filename, payload.mime_type, payload.bytes)
    return {'storage_key': key, 'url': url, 'fields': fields, 'expires_in': 900}

@router.post('/logo/finalize')
def finalize_logo_upload(tenant_id: str = Query(...), storage_key: str = Query(...), mime_type: str = Query(...), width_px: int = 240, height_px: int = 80, user: User = Depends(current_user), db: Session = Depends(get_db)):
    asset = db.query(BrandingAsset).filter_by(tenant_id=tenant_id).one_or_none()
    if asset:
        asset.logo_storage_key = storage_key; asset.mime_type = mime_type; asset.width_px = width_px; asset.height_px = height_px; asset.uploaded_by = user.id
    else:
        asset = BrandingAsset(tenant_id=tenant_id, logo_storage_key=storage_key, mime_type=mime_type, width_px=width_px, height_px=height_px, uploaded_by=user.id)
        db.add(asset)
    db.commit()
    return {'ok': True}

@router.get('/logo/url')
def get_logo_url(tenant_id: str, db: Session = Depends(get_db)):
    asset = db.query(BrandingAsset).filter_by(tenant_id=tenant_id).one_or_none()
    if not asset:
        raise HTTPException(404, 'No logo for tenant')
    return {'url': presigned_logo_get(asset.logo_storage_key, 300), 'width_px': asset.width_px, 'height_px': asset.height_px}
