from datetime import datetime
from typing import List, Optional
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.security import current_user
from app.core.auth import User
from app.services import rbac, storage
from app.models.documents import Document, DocumentEvent, DocumentAccess, DocOwnerType, DocStatus

router = APIRouter(prefix="/documents", tags=["documents"])

class DocumentCreate(BaseModel):
    owner_type: DocOwnerType
    owner_id: str
    title: str
    mime_type: str
    bytes: int = Field(ge=1)
    tags: List[str] = []

class PreSignedUpload(BaseModel):
    storage_key: str
    url: str
    fields: Optional[dict] = None
    expires_in: int = 900

class PreSignedDownload(BaseModel):
    url: str
    expires_in: int = 60

class DocumentOut(BaseModel):
    id: UUID
    owner_type: DocOwnerType
    owner_id: str
    title: str
    filename: str
    mime_type: str
    bytes: int
    status: DocStatus
    tags: List[str] = []
    uploaded_by: str
    uploaded_at: datetime
    expires_at: Optional[datetime] = None
    version: int
    class Config:
        from_attributes = True

class DocumentPatch(BaseModel):
    status: Optional[DocStatus] = None
    tags: Optional[List[str]] = None
    expires_at: Optional[datetime] = None
    bump_version: bool = False

class ShareAccess(BaseModel):
    principal_type: DocOwnerType
    principal_id: str
    can_view: bool = True
    can_update: bool = False
    can_share: bool = False

@router.post("/prepare-upload", response_model=PreSignedUpload)
def prepare_upload(payload: DocumentCreate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    storage_key = storage.make_key(payload.owner_type.value, payload.owner_id, payload.title, user.id)
    doc = Document(
        owner_type=payload.owner_type, owner_id=payload.owner_id,
        title=payload.title, filename=payload.title, mime_type=payload.mime_type,
        bytes=payload.bytes, storage_key=storage_key, status=DocStatus.PENDING,
        tags=payload.tags, uploaded_by=user.id
    )
    db.add(doc); db.commit(); db.refresh(doc)
    url, fields = storage.presigned_post(storage_key, payload.mime_type, payload.bytes)
    db.add(DocumentEvent(document_id=doc.id, actor_user_id=user.id, action="UPLOAD_INIT", metadata={}))
    db.commit()
    return PreSignedUpload(storage_key=storage_key, url=url, fields=fields, expires_in=900)

@router.post("/{doc_id}/finalize", response_model=DocumentOut)
def finalize_upload(doc_id: UUID, filename: str = Query(...), sha256: str = Query(...), user: User = Depends(current_user), db: Session = Depends(get_db)):
    doc = db.get(Document, doc_id)
    if not doc: raise HTTPException(404, "Document not found")
    if not rbac.can_update_doc(user, doc): raise HTTPException(403, "Forbidden")
    doc.filename = filename; doc.sha256 = sha256
    db.commit(); db.refresh(doc)
    db.add(DocumentEvent(document_id=doc.id, actor_user_id=user.id, action="UPLOAD_FINAL", metadata={"sha256": sha256}))
    db.commit()
    return DocumentOut.model_validate(doc)

@router.get("", response_model=List[DocumentOut])
def list_documents(owner_type: Optional[DocOwnerType] = None, owner_id: Optional[str] = None, tag: Optional[str] = None, status: Optional[DocStatus] = None, user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = db.query(Document)
    if owner_type: q = q.filter(Document.owner_type == owner_type)
    if owner_id: q = q.filter(Document.owner_id == owner_id)
    if status: q = q.filter(Document.status == status)
    if tag: q = q.filter(Document.tags.any(tag))
    q = rbac.filter_docs_for_user(q, user)
    return [DocumentOut.model_validate(d) for d in q.order_by(Document.uploaded_at.desc()).all()]

@router.get("/{doc_id}/download", response_model=PreSignedDownload)
def download_document(doc_id: UUID, user: User = Depends(current_user), db: Session = Depends(get_db)):
    doc = db.get(Document, doc_id)
    if not doc: raise HTTPException(404)
    if not rbac.can_view_doc(user, doc): raise HTTPException(403)
    url = storage.presigned_get(doc.storage_key, expires_seconds=60)
    db.add(DocumentEvent(document_id=doc.id, actor_user_id=user.id, action="VIEW", metadata={}))
    db.commit()
    return PreSignedDownload(url=url, expires_in=60)

@router.patch("/{doc_id}", response_model=DocumentOut)
def patch_document(doc_id: UUID, payload: DocumentPatch, user: User = Depends(current_user), db: Session = Depends(get_db)):
    doc = db.get(Document, doc_id)
    if not doc: raise HTTPException(404)
    if not rbac.can_update_doc(user, doc): raise HTTPException(403)
    if payload.status is not None: doc.status = payload.status
    if payload.tags is not None: doc.tags = payload.tags
    if payload.expires_at is not None: doc.expires_at = payload.expires_at
    if payload.bump_version: doc.version += 1
    db.commit(); db.refresh(doc)
    db.add(DocumentEvent(document_id=doc.id, actor_user_id=user.id, action="PATCH", metadata=payload.model_dump()))
    db.commit()
    return DocumentOut.model_validate(doc)

@router.post("/{doc_id}/share")
def share_document(doc_id: UUID, access: ShareAccess, user: User = Depends(current_user), db: Session = Depends(get_db)):
    doc = db.get(Document, doc_id)
    if not doc: raise HTTPException(404)
    if not rbac.can_share_doc(user, doc): raise HTTPException(403)
    existing = db.query(DocumentAccess).filter_by(document_id=doc.id, principal_type=access.principal_type, principal_id=access.principal_id).one_or_none()
    if existing:
        existing.can_view = access.can_view; existing.can_update = access.can_update; existing.can_share = access.can_share
    else:
        db.add(DocumentAccess(document_id=doc.id, principal_type=access.principal_type, principal_id=access.principal_id, can_view=access.can_view, can_update=access.can_update, can_share=access.can_share))
    db.add(DocumentEvent(document_id=doc.id, actor_user_id=user.id, action="SHARE", metadata=access.model_dump()))
    db.commit()
    return {"ok": True}

@router.get("/{doc_id}/events")
def get_events(doc_id: UUID, user: User = Depends(current_user), db: Session = Depends(get_db)):
    doc = db.get(Document, doc_id)
    if not doc: raise HTTPException(404)
    if not rbac.can_view_doc(user, doc): raise HTTPException(403)
    ev = db.query(DocumentEvent).filter_by(document_id=doc_id).order_by(DocumentEvent.created_at.asc()).all()
    return [{"action": e.action, "actor_user_id": e.actor_user_id, "created_at": e.created_at, "metadata": e.metadata} for e in ev]
