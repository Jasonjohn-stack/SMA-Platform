from typing import List, Optional, Dict, Set
from uuid import UUID
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.security import current_user
from app.core.auth import User
from app.services import rbac
from app.models.chat import ChatRoom, ChatParticipant, ChatMessage, ChatMessageEvent, RoomType

router = APIRouter(prefix="/chat", tags=["chat"])

class RoomCreate(BaseModel):
    room_type: RoomType
    name: Optional[str] = None
    context_id: Optional[str] = None

class RoomOut(BaseModel):
    id: UUID
    room_type: RoomType
    name: Optional[str]
    context_id: Optional[str]
    created_by: str
    created_at: datetime
    class Config: from_attributes = True

class ParticipantUpsert(BaseModel):
    principal_type: str
    principal_id: str
    role: str = "MEMBER"
    can_post: bool = True
    can_invite: bool = False

class MessageCreate(BaseModel):
    body: Optional[str] = None
    attachment_document_id: Optional[UUID] = None

class MessageOut(BaseModel):
    id: int
    room_id: UUID
    sender_user_id: str
    body: Optional[str]
    attachment_document_id: Optional[UUID]
    created_at: datetime
    class Config: from_attributes = True

@router.post("/rooms", response_model=RoomOut)
def create_room(payload: RoomCreate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    room = ChatRoom(room_type=payload.room_type, name=payload.name, context_id=payload.context_id, created_by=user.id)
    db.add(room); db.commit(); db.refresh(room)
    db.add(ChatParticipant(room_id=room.id, principal_type="ADMIN", principal_id=user.id, role="ADMIN", can_post=True, can_invite=True))
    db.commit()
    return RoomOut.model_validate(room)

@router.get("/rooms", response_model=List[RoomOut])
def list_rooms(context_id: Optional[str] = None, room_type: Optional[RoomType] = None, user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = db.query(ChatRoom)
    if context_id: q = q.filter_by(context_id=context_id)
    if room_type: q = q.filter_by(room_type=room_type)
    q = rbac.filter_rooms_for_user(q, user)
    return [RoomOut.model_validate(r) for r in q.order_by(ChatRoom.created_at.desc()).all()]

@router.post("/rooms/{room_id}/participants")
def upsert_participant(room_id: UUID, p: ParticipantUpsert, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not rbac.user_is_room_admin(user, room_id, db): raise HTTPException(403)
    participant = db.query(ChatParticipant).filter_by(room_id=room_id, principal_type=p.principal_type, principal_id=p.principal_id).one_or_none()
    if participant:
        participant.role = p.role; participant.can_post = p.can_post; participant.can_invite = p.can_invite
    else:
        db.add(ChatParticipant(room_id=room_id, principal_type=p.principal_type, principal_id=p.principal_id, role=p.role, can_post=p.can_post, can_invite=p.can_invite))
    db.commit()
    return {"ok": True}

@router.get("/rooms/{room_id}/messages", response_model=List[MessageOut])
def get_messages(room_id: UUID, after_id: Optional[int] = None, limit: int = 100, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not rbac.can_view_room(user, room_id, db): raise HTTPException(403)
    q = db.query(ChatMessage).filter_by(room_id=room_id)
    if after_id: q = q.filter(ChatMessage.id > after_id)
    msgs = q.order_by(ChatMessage.id.asc()).limit(limit).all()
    return [MessageOut.model_validate(m) for m in msgs]

@router.post("/rooms/{room_id}/messages", response_model=MessageOut)
def post_message(room_id: UUID, payload: MessageCreate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not rbac.can_post_room(user, room_id, db): raise HTTPException(403)
    msg = ChatMessage(room_id=room_id, sender_user_id=user.id, body=payload.body, attachment_document_id=payload.attachment_document_id)
    db.add(msg); db.commit(); db.refresh(msg)
    db.add(ChatMessageEvent(message_id=msg.id, actor_user_id=user.id, action="SENT", metadata={}))
    db.commit()
    return MessageOut.model_validate(msg)

# --- Minimal WebSocket broadcast hub (in-memory) ---
room_connections: Dict[str, Set[WebSocket]] = {}

@router.websocket("/rooms/{room_id}/ws")
async def room_ws(websocket: WebSocket, room_id: str):
    await websocket.accept()
    room_connections.setdefault(room_id, set()).add(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            for ws in list(room_connections.get(room_id, set())):
                if ws is not websocket:
                    await ws.send_text(data)
    except WebSocketDisconnect:
        room_connections.get(room_id, set()).discard(websocket)
