import enum
from sqlalchemy import Column, Text, BigInteger, Enum, TIMESTAMP, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from app.core.db import Base

class RoomType(enum.Enum):
    DIRECT = "DIRECT"
    GROUP = "GROUP"
    SMA = "SMA"
    STRATEGY = "STRATEGY"
    TICKET = "TICKET"

class ChatRoom(Base):
    __tablename__ = "chat_rooms"
    id = Column(UUID(as_uuid=True), primary_key=True)
    room_type = Column(Enum(RoomType), nullable=False)
    name = Column(Text)
    context_id = Column(Text)
    created_by = Column(Text, nullable=False)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

class ChatParticipant(Base):
    __tablename__ = "chat_participants"
    room_id = Column(UUID(as_uuid=True), primary_key=True)
    principal_type = Column(Text, primary_key=True)
    principal_id = Column(Text, primary_key=True)
    role = Column(Text, nullable=False, default="MEMBER")
    can_post = Column(Boolean, nullable=False, default=True)
    can_invite = Column(Boolean, nullable=False, default=False)

class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    room_id = Column(UUID(as_uuid=True), nullable=False)
    sender_user_id = Column(Text, nullable=False)
    body = Column(Text)
    attachment_document_id = Column(UUID(as_uuid=True))
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

class ChatMessageEvent(Base):
    __tablename__ = "chat_message_events"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    message_id = Column(BigInteger, nullable=False)
    actor_user_id = Column(Text, nullable=False)
    action = Column(Text, nullable=False)
    metadata = Column(Text, nullable=False, default="{}")
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
