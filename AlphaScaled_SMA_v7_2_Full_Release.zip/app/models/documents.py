import enum
from sqlalchemy import Column, Text, BigInteger, Enum, ARRAY, TIMESTAMP, JSON, Integer
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from app.core.db import Base

class DocOwnerType(enum.Enum):
    ALLOCATOR = "ALLOCATOR"
    PORTFOLIO_MANAGER = "PORTFOLIO_MANAGER"
    STRATEGY = "STRATEGY"
    FAMILY_OFFICE = "FAMILY_OFFICE"
    HNW = "HNW"
    ADMIN = "ADMIN"
    CUSTODIAN = "CUSTODIAN"
    ADMINISTRATOR = "ADMINISTRATOR"

class DocStatus(enum.Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    EXPIRED = "EXPIRED"
    REJECTED = "REJECTED"

class Document(Base):
    __tablename__ = "documents"
    id = Column(UUID(as_uuid=True), primary_key=True)
    owner_type = Column(Enum(DocOwnerType), nullable=False)
    owner_id = Column(Text, nullable=False)
    title = Column(Text, nullable=False)
    filename = Column(Text, nullable=False)
    mime_type = Column(Text, nullable=False)
    bytes = Column(BigInteger, nullable=False)
    storage_key = Column(Text, nullable=False)
    sha256 = Column(Text)
    status = Column(Enum(DocStatus), nullable=False, default=DocStatus.PENDING)
    tags = Column(ARRAY(Text), default=[])
    uploaded_by = Column(Text, nullable=False)
    uploaded_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
    expires_at = Column(TIMESTAMP(timezone=True))
    version = Column(Integer, nullable=False, default=1)

class DocumentAccess(Base):
    __tablename__ = "document_access"
    id = Column(UUID(as_uuid=True), primary_key=True)
    document_id = Column(UUID(as_uuid=True), nullable=False)
    principal_type = Column(Enum(DocOwnerType), nullable=False)
    principal_id = Column(Text, nullable=False)
    can_view = Column(Integer, nullable=False, default=True)
    can_update = Column(Integer, nullable=False, default=False)
    can_share = Column(Integer, nullable=False, default=False)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

class DocumentEvent(Base):
    __tablename__ = "document_events"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    document_id = Column(UUID(as_uuid=True), nullable=False)
    actor_user_id = Column(Text, nullable=False)
    action = Column(Text, nullable=False)
    metadata = Column(JSON, nullable=False, default={})
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
