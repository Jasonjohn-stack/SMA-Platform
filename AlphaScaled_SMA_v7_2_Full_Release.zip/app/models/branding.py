from sqlalchemy import Column, Text, Integer, TIMESTAMP
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from app.core.db import Base

class BrandingAsset(Base):
    __tablename__ = 'branding_assets'
    id = Column(UUID(as_uuid=True), primary_key=True)
    tenant_id = Column(Text, nullable=False)
    logo_storage_key = Column(Text, nullable=False)
    mime_type = Column(Text, nullable=False)
    width_px = Column(Integer)
    height_px = Column(Integer)
    uploaded_by = Column(Text, nullable=False)
    uploaded_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
