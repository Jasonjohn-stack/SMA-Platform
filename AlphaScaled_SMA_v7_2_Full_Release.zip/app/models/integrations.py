from sqlalchemy import Column, Text, Boolean, TIMESTAMP
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from app.core.db import Base

class IntegrationEndpoint(Base):
    __tablename__ = 'integration_endpoints'
    id = Column(UUID(as_uuid=True), primary_key=True)
    partner = Column(Text, nullable=False)
    base_url = Column(Text, nullable=False)
    api_token = Column(Text, nullable=False)
    active = Column(Boolean, nullable=False, default=True)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

class IntegrationAllowedIP(Base):
    __tablename__ = 'integration_allowed_ips'
    id = Column(UUID(as_uuid=True), primary_key=True)
    integration_id = Column(UUID(as_uuid=True), nullable=False)
    cidr = Column(Text, nullable=False)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
